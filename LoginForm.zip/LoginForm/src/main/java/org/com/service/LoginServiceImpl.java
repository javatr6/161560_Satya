package org.com.service;

import org.cap.dao.ILoginDao;
import org.cap.dao.LoginDAOImpl;
import org.cap.model.LoginBean;

public class LoginServiceImpl implements ILoginService {
	ILoginDao loginDAO = new LoginDAOImpl();
	
	@Override
	public boolean isValidLogin(LoginBean loginBean) {
		// TODO Auto-generated method stub
		if(loginDAO.isValidLogin(loginBean)) {
			return true;
		}else {
			return false;
		}
		
	}

} 