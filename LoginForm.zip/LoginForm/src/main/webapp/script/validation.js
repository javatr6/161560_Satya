function validate(){
	var flag=false;
	var userName=s1.userName.value
	var userPassword=s1.userPwd.value
	if(userName==""||userName==null){
		document.getElementById('userErrMsg').innerHTML="Please Enter User Name"
			flag=false;
	}else if(userPassword==""||userPassword==null){
		document.getElementById('pwdErrMsg').innerHTML="Please Enter User Password"
			flag=false;
	}else{
		flag=true;
	}
	
	return flag;
}