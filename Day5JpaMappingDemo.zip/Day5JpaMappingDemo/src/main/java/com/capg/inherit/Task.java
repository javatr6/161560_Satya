package com.capg.inherit;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Task extends Module{
	@Id
	private String taskName;
	
	public Task() {
	}
	public Task(String taskName) {
		super();
		this.taskName = taskName;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	@Override
	public String toString() {
		return "Task [taskName=" + taskName + "]";
	}
	
	

}
