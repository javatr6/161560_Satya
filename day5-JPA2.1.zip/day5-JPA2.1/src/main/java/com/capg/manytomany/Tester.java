package com.capg.manytomany;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Tester {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");

		EntityManager entityManager=emf.createEntityManager();

		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		
		Events servlets=new Events("123-servlets","servlet",LocalDate.of(2018, 9, 21));
		Events iot=new Events("456-iot","iot",LocalDate.of(2017, 5, 14));
		Events python=new Events("789-python","python",LocalDate.of(2015,9, 12));
		
		Delegates delegates1=new Delegates(1,"Satya");
		Delegates delegates2=new Delegates(2,"Vani");
		Delegates delegates3=new Delegates(3,"Sree");
		Delegates delegates4=new Delegates(4,"Sai");
		Delegates delegates5=new Delegates(5,"Sri");
		
		delegates1.getEvents().add(servlets);
		delegates1.getEvents().add(iot);
		delegates2.getEvents().add(python);
		delegates1.getEvents().add(servlets);
		delegates3.getEvents().add(python);
		delegates1.getEvents().add(iot);
		delegates1.getEvents().add(servlets);
		delegates1.getEvents().add(iot);
		delegates1.getEvents().add(python);
		
		entityManager.persist(delegates1);
		entityManager.persist(delegates2);
		entityManager.persist(delegates3);
		entityManager.persist(delegates4);
		entityManager.persist(delegates5);
		
		entityManager.persist(servlets);
		entityManager.persist(iot);
		entityManager.persist(python);
		
		
		transaction.commit();
		entityManager.close();
	}
}
