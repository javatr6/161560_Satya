package bean;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class successBean {

	
	private WebDriver driver;
	private String message;

	public successBean(String message) {
		super();
		this.message = message;
	}

	public successBean() {
		super();
	}
	public successBean(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(this.driver, this); 
	}

	public String getMessage() {
		return driver.findElement(By.tagName("h1")).getText();
	}

	public void setMessage(String message) {
		this.message = message;
	}
}
