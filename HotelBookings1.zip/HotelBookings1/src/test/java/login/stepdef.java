package login;
import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdef {

	private WebDriver driver;

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Selenium\\chromedriver.exe");
		driver=new ChromeDriver();
	}
	@Given("^open login page$")
	public void open_login_page() throws Throwable {
		
		driver.get("http://localhost:8081/HotelBookings/login.html");
		String heading=driver.findElement(By.xpath("//*[@id='mainCnt']/div/div[1]/h1")).getText();

		assertEquals("Hotel Booking Application",heading);
	}

	@Given("^username and password$")
	public void username_and_password() throws Throwable {
		driver.findElement(By.name("userName")).sendKeys("capgemini");
		driver.findElement(By.name("userPwd")).sendKeys("capg1234");
		Thread.sleep(3000);
	    
	}

	@When("^login validate details$")
	public void login_validate_details() throws Throwable {
		WebElement login=driver.findElement(By.name("login"));
		login.click();
		Thread.sleep(3000);
	}

	@Then("^redirect to hotelbooking page$")
	public void redirect_to_hotelbooking_page() throws Throwable {
		driver.navigate().to("http://localhost:8081/HotelBookings/pages/hotelbooking.html");
	}

	@Given("^username$")
	public void username() throws Throwable {
		driver.findElement(By.name("userName")).sendKeys("");
		Thread.sleep(3000);
	}

	@When("^login is performed$")
	public void login_is_performed() throws Throwable {
		WebElement login=driver.findElement(By.name("login"));
		login.click();
		Thread.sleep(3000);
	}

	@Then("^show invalid username$")
	public void show_invalid_username() throws Throwable {
		
		String nameErrMsg=driver.findElement(By.xpath("//*[@id=\"userErrMsg\"]")).getText();
		assertEquals("* Please enter userName.",nameErrMsg);
		Thread.sleep(3000);
	}

	@Given("^password$")
	public void password() throws Throwable {
	   
		driver.findElement(By.name("userName")).sendKeys("Capgemini");
		driver.findElement(By.name("userPwd")).sendKeys("");
		Thread.sleep(3000);
	}

	@When("^login$")
	public void login() throws Throwable {
		WebElement login=driver.findElement(By.name("login"));
		login.click();
		Thread.sleep(3000);
	}

	@Then("^show invalid password$")
	public void show_invalid_password() throws Throwable {
		String passwordErrMsg=driver.findElement(By.xpath("//*[@id=\"pwdErrMsg\"]")).getText();
		assertEquals("* Please enter password.",passwordErrMsg);
		Thread.sleep(3000);
	}	
	
	@After
	public void tearDown() {
		driver.quit();
	}
}
